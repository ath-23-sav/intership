import React from 'react'

const Footer = () => {
  return (
    <div className='' class="bg-primary p-3">
 <p>&copy; 2024 Fresh & Delicious. All rights reserved.</p>    </div>
  )
}

export default Footer
